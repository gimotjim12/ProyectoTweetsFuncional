package service;

import model.Tweet;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TweetAnalyticsService {

    public static List<Tweet> transformarTweets(List<Tweet> tweets, Function<Tweet, Tweet> transformacion) {
        return tweets.stream().map(transformacion).collect(Collectors.toList());
    }

    public static void procesarTweets(List<Tweet> tweets, Function<Tweet, Tweet> transformacion, Consumer<Tweet> accionFinal) {
        tweets.stream().map(transformacion).forEach(accionFinal);
    }

    public static double calcularPromedioLongitud(List<Tweet> tweets, String sentimiento) {
        return tweets.stream()
                .filter(t -> t.getSentiment().equalsIgnoreCase(sentimiento))
                .mapToInt(t -> t.getText().length())
                .average().orElse(0.0);
    }

    public static Map<String, Long> contarTweetsPorSentimiento(List<Tweet> tweets) {
        return tweets.stream()
                .collect(Collectors.groupingBy(t -> t.getSentiment().toLowerCase(), Collectors.counting()));
    }
}

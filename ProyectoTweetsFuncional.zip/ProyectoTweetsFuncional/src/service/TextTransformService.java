package service;

import model.Tweet;
import java.util.function.Function;

public class TextTransformService {
    public static Function<Tweet, Tweet> crearTransformacion(boolean toUpper) {
        return t -> {
            String text = t.getText();
            if (text == null) text = "";
            text = text.replaceAll("@\\w+", "");
            text = text.replaceAll("#", "");
            text = text.replaceAll("https?://\\S+", "");
            text = text.replaceAll("\\s+", " ").trim();
            if (toUpper) text = text.toUpperCase();
            t.setText(text);
            return t;
        };
    }
}

package service;

import model.Tweet;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class TweetLoader {

    public static Supplier<List<Tweet>> crearLectorTweets(String rutaArchivo) {
        return () -> {
            List<Tweet> tweets = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
                String linea;
                boolean primera = true;
                while ((linea = br.readLine()) != null) {
                    if (primera) { primera = false; continue; }
                    if (linea.trim().isEmpty()) continue;
                    String[] p = parse(linea);
                    if (p.length < 4) continue;
                    tweets.add(new Tweet(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim()));
                }
            } catch (IOException e) {
                System.err.println("Error leyendo CSV: " + e.getMessage());
            }
            return tweets;
        };
    }

    private static String[] parse(String line) {
        List<String> cols = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (char c : line.toCharArray()) {
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                cols.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        cols.add(cur.toString());
        return cols.toArray(new String[0]);
    }
}

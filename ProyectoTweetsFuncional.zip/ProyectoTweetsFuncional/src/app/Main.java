package app;

import model.Tweet;
import report.ReportGenerator;
import service.TextTransformService;
import service.TweetAnalyticsService;
import service.TweetLoader;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Main {
 
    public static void main(String[] args) {
        String rutaCsv = "C:/Users/Huawei/Downloads/ProyectoTweetsFuncional/data/twitters.csv";
        String outTweets = "output/tweets_limpios.txt";
        String outResumen = "output/resumen_estadisticas.txt";

        try { Files.createDirectories(Paths.get("output")); } catch (Exception ignored) {}

        Supplier<List<Tweet>> lector = TweetLoader.crearLectorTweets(rutaCsv);

        Runnable pipeline = () -> {
            List<Tweet> tweets = lector.get();

            var transformacion = TextTransformService.crearTransformacion(false);
            List<Tweet> resultado = new ArrayList<>();
            Consumer<Tweet> recolector = resultado::add;

            TweetAnalyticsService.procesarTweets(tweets, transformacion, recolector);

            ReportGenerator.guardarTweetsLimpios(resultado, outTweets);

            Map<String, Long> conteo = TweetAnalyticsService.contarTweetsPorSentimiento(resultado);

            double promPos = TweetAnalyticsService.calcularPromedioLongitud(resultado, "Positive");
            double promNeg = TweetAnalyticsService.calcularPromedioLongitud(resultado, "Negative");
            double promNeu = TweetAnalyticsService.calcularPromedioLongitud(resultado, "Neutral");

            String resumen = "Resumen estadísticas\n" +
                    "---------------------\n" +
                    "Total tweets: " + resultado.size() + "\n\n" +
                    "Conteo por sentimiento: " + conteo + "\n\n" +
                    "Promedios:\n" +
                    "Positive: " + promPos + "\n" +
                    "Negative: " + promNeg + "\n" +
                    "Neutral: " + promNeu + "\n";

            ReportGenerator.guardarResumenEstadisticas(resumen, outResumen);
        };

        pipeline.run();
    }
}

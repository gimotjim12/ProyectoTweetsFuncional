package report;

import model.Tweet;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ReportGenerator {

    public static void guardarTweetsLimpios(List<Tweet> tweets, String ruta) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (Tweet t : tweets) {
                bw.write(t.getId() + "\t" + t.getEntity() + "\t" + t.getSentiment() + "\t" + t.getText());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error guardando tweets limpios: " + e.getMessage());
        }
    }

    public static void guardarResumenEstadisticas(String resumen, String ruta) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write(resumen);
        } catch (IOException e) {
            System.err.println("Error guardando resumen: " + e.getMessage());
        }
    }
}

package model;

public class Tweet {
    private String id;
    private String entity;
       private String sentiment;
    private String text;

    public Tweet(String id, String entity, String sentiment, String text) {
        this.id = id;
        this.entity = entity;
        this.sentiment = sentiment;
        this.text = text;
    }

    public String getId() { return id; }
    public String getEntity() { return entity; }
    public String getSentiment() { return sentiment; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    @Override
    public String toString() {
        return "Tweet{id='" + id + "', entity='" + entity + "', sentiment='" +
                sentiment + "', text='" + text + "'}";
    }
}
